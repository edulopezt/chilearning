<?php
/**
 * Plugin strings are defined here.
 *
 * @package     block_sence
 * @category    string
 * @copyright   2020 Felipe Uzcátegui <felipe.uzcategui@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Integración SENCE';
$string['codigocurso'] = 'Código SENCE del Curso';
$string['lineadecap'] = 'Líneas de Capacitación';
$string['grupobecarios'] = 'Nombre Grupo Becarios';
$string['permit'] = 'Habilitar curso solo para alumnos con código SENCE';
$string['sence:myaddinstance'] = 'Integrar SENCE';
$string['sence:addinstance'] = 'Integrar SENCE';

$string['gate_redirect'] = 'Debe registrar su asistencia SENCE antes de acceder al contenido del curso.';
